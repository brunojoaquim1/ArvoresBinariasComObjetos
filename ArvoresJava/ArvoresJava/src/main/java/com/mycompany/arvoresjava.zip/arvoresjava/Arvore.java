/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.arvoresjava;
public class Arvore{
	
	private NodoArv raiz;
	
	public Arvore(){
		raiz = null;
	}
	
	public void insNodo(Cidades c){
		if( raiz == null )
		  raiz = new NodoArv( c );
		else
		  insere( raiz, c );
	}
	
	public void insere( NodoArv atual, Cidades c ){
	  	if( c.getPrimeiraLetra() < atual.getDado().getPrimeiraLetra() ){
	  		if( atual.getEsq() == null ){
	  			NodoArv aux = new NodoArv(c);
	  			atual.setEsq(aux);
	  			atual.getEsq().setPai(atual);
	  			
	  		}
	  		else
	  		  insere( atual.getEsq(), c );
	  	}
	  	else{	  
	  		if( atual.getDir() == null){
	  			NodoArv aux = new NodoArv(c);
	  			atual.setDir(aux);
	  			atual.getDir().setPai(atual);
	  		}
	  		else
	  		  insere( atual.getDir(), c );
	     }
	  }	  
	
	
	public void preFixado(){
		preFix( raiz );
	}
	
	public void preFix( NodoArv raiz){
		if( raiz == null )
		  return;
		
		System.out.print( raiz.getDado().getNome() + " ");
		
		preFix( raiz.getEsq() );
		preFix( raiz.getDir() );
	}
	
	public void central(){
		inFix( raiz );
	}
	
	public void inFix( NodoArv raiz){
		if( raiz == null )
		  return;
		
		inFix( raiz.getEsq() );
		
		System.out.print( raiz.getDado().getNome() + " ");
		
		inFix( raiz.getDir() );
	}
	
	public void posFixado(){
		posFix( raiz );
	}
	
	public void posFix( NodoArv raiz){
		if( raiz == null )
		  return;

		posFix( raiz.getEsq() );
		posFix( raiz.getDir() );
		
		System.out.print( raiz.getDado().getNome() + " ");		
	}
	
	public boolean pesquisa(Cidades c ){
	//Retorna V ou F, caso o valor exista ou n�o
		boolean res = pesq_arv( raiz, c );
		return res;
	}
	
	public boolean pesq_arv( NodoArv raiz, Cidades c ){		
	//Realiza a pesquisa por um m�todo n�o recursivo.
		boolean achou = false;
		NodoArv aux = raiz;
		
		while((achou == false) && (aux!= null)){
			
			if(aux.getDado().getPrimeiraLetra()==c.getPrimeiraLetra()){
				achou = true;
			}
			else{
				if(c.getPrimeiraLetra()<=aux.getDado().getPrimeiraLetra())
					aux = aux.getEsq();
				else
					aux = aux.getDir();
			}
		}
		return achou;
	}
	
	public NodoArv pesquisa_rec( Cidades c ){
	//Retorna V ou F, caso o valor exista ou n�o
		NodoArv res = pesq_arv_rec( raiz, c );
		return res;
	}
	
	public NodoArv pesq_arv_rec(NodoArv raiz,Cidades c){
				
		NodoArv res=null;
				
		if(raiz!=null){
			if(raiz.getDado().getPrimeiraLetra()==c.getPrimeiraLetra()){
				res=raiz;
			}
			else{
				if(c.getPrimeiraLetra() < raiz.getDado().getPrimeiraLetra())
					res = pesq_arv_rec(raiz.getEsq(),c);
				else
					res = pesq_arv_rec(raiz.getDir(),c);
			}
		}
		return res;
	}

    public void remove(Cidades c){
    	NodoArv atual;
    	
    	// Verifica se o nodo existe  	
    	atual = this.pesquisa_rec( c );
    	
    	if(atual == null){
    		System.out.println("O Elemento "+c.getNome()+" Nao Esta Presente na Arvore");
		}
			
		// Chamada de M�todos
		if((atual.getEsq()==null) && (atual.getDir()==null))
    		removeFolha(atual);
    	else{
			if((atual.getEsq()!=null) && (atual.getDir()!=null))
    			removeDoisFilhos( atual );
    		else
    			removeUmFilho( atual );
    	}		
    }    	
    
	public void removeFolha( NodoArv atual){
	// Remove uma folha da �rvore - Nodo folha n�o possui filhos
	
		NodoArv pai = atual.getPai();
		if(pai==null){ //o nodo a ser exclu�do � a ra�z da �rvore
			raiz = null;
		}
		else{
			if(pai.getEsq()==atual){
				pai.setEsq(null);
			}
			else{
				pai.setDir(null);
			}
		}
	}
	
	public void removeUmFilho( NodoArv atual ){
	//Remove um nodo que possui um filho
	
		NodoArv pai = atual.getPai();
		
		if(pai==null){//o nodo a ser exclu�do � a ra�z da �rvore
			if(atual.getEsq()!=null){
				raiz = atual.getEsq();
			}
			else{
				raiz = atual.getDir();
			}
		}
		else{
			if(atual.getEsq()==null){
				if(pai.getDir()==atual){
					pai.setDir(atual.getDir());
				}
				else{ //pai.getEsq()==atual
					pai.setEsq(atual.getDir());
				}
			}
			else{ //atual.getDir()==null
		
				if(pai.getDir()==atual){
					pai.setDir(atual.getEsq());
				}
				else{ //pai.getEsq()==atual
					pai.setEsq(atual.getEsq());
				}
			
			}	
		}
	} // fim m�todo remove com 1 filho


	public void removeDoisFilhos( NodoArv atual ){
	//Remove um nodo que possui dois filhos
	
	
		//Busca o elemento mais da direita (desce a esq. e depois a direita)
		
		NodoArv aux=atual.getEsq();
		
		NodoArv auxPai=null;
		
		while(aux.getDir()!=null){
			aux = aux.getDir();
		}
		//Nodo Folha
		if((aux.getEsq()==null) && (aux.getDir()==null)){
			atual.setDado(aux.getDado());
			
			auxPai = aux.getPai();
			if(auxPai == atual){ //um nivel abaixo do dado a ser exclu�do
				atual.setEsq(null); //anula a �rv. esquerda
			}
			else{
				auxPai.setDir(null);
			}
		}
		
		//Nodo com um filho a esquerda
		if((aux.getEsq()!=null) && (aux.getDir()==null)){
			atual.setDado(aux.getDado());
										
			auxPai = aux.getPai();
			if(auxPai == atual){ //um n�vel abaixo do dado a ser exclu�do
				atual.setEsq(aux.getEsq());
			}
			else{
				auxPai.setDir(aux.getEsq());
			}

		}				
	}// fim do m�todo
}
