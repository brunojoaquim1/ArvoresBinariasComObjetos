package com.mycompany.arvoresjava;
import java.util.Scanner;

public class TestaArvore{
    
        public static void menuLista(){                  		
                    System.out.println("[1]  INSERE CIDADE");
                    System.out.println("[2]  REMOVE CIDADE");
                    System.out.println("[3]  CONSULTA CIDADE");
                    System.out.println("[4]  ESCREVE CIDADES A/Z");
                    System.out.println("[5]  ESCREVE CIDADES Z/A");
                    System.out.println("[6]  ESCREVE PAISES A/Z");
                    System.out.println("[7]  ESCREVE PAISES Z/A");
                    System.out.println("[8]  ESCREVE JOGADORES ORDEM CRESCENTE");
                    System.out.println("[9]  ESCREVE JOGADORES ORDEM DECRESCENTE");
                    System.out.println("[10] CONSULTA CIDADES POR PAIS");
                    System.out.println("[11] CONSULTA JOGADORES POR PAIS");
                    System.out.println("[12] SAIR");
        }
        
        public static Cidades cadastraCidade(){
            
            String nome, pais,latitude, longitude;
            int jogadores;
            
            Scanner lerNome = new Scanner(System.in);
            Scanner lerPais = new Scanner(System.in);
            Scanner lerLatitude = new Scanner(System.in);
            Scanner lerLongitude = new Scanner(System.in);
            Scanner lerjogadores = new Scanner(System.in);
            
            System.out.println("Digite o nome da cidade:");
            nome = lerNome.nextLine();
            System.out.println("Digite o nome do pais:");
            pais = lerPais.nextLine();
            System.out.println("Digite o nome a Latitude:");
            latitude = lerLatitude.nextLine();           
            System.out.println("Digite a longitude:");
            longitude = lerLongitude.nextLine();
            System.out.println("Digite o numero de jogadores:");
            jogadores = lerjogadores.nextInt();
            
            Cidades cidade = new Cidades(nome,pais,latitude,longitude,jogadores);
            
            return cidade;
            

            
            
        }

	public static void main(String args[]){
            
            Scanner ler = new Scanner(System.in);
            
            int menuOption = 10;
            
		
            Arvore_OLD arv = new Arvore_OLD();
            
	    System.out.println( "Inserindo Valores: " );
            Cidades c1 = new Cidades("Caxias do Sul","Brasil","-29.1678","-51.1794",20);
            Cidades c2 = new Cidades("Bage","Brasil","-31.3285","-54.1073",45);
            Cidades c3 = new Cidades("Recife","Brasil","-27.5969","-34.8813",45);
            Cidades c4 = new Cidades("Florianopolis","Brasil","-8.05428","-34.8813",12);
            Cidades c5 = new Cidades("Sao Paulo","Brasil","-23.5489","-46.6388",200);
            
	    arv.insNodo(c1);
	    arv.insNodo(c2);
	    arv.insNodo(c3);
            arv.insNodo(c4);
            arv.insNodo(c5);
            
            System.out.printf("Informe uma opcao para o menu:\n");
            menuLista();
            menuOption = ler.nextInt();
            
            do{
                switch(menuOption){
                    case 1 :                    		
                    System.out.println("************************************");
                    System.out.println("INSERE CIDADE");
                    System.out.println("************************************");
                    Cidades cidade = null ;
                    cidade = cadastraCidade();
                    
                    arv.insNodo(cidade);
                    
                break;
                
                case 2:
                    System.out.println("************************************");
                    System.out.println("REMOVE CIDADE");
                    System.out.println("************************************");
		
                break;
                case 3:
                    System.out.println("************************************");
                    System.out.println("CONSULTA CIDADE");
                    System.out.println("************************************");
                break;
                case 4:
                    System.out.println("************************************");
                    System.out.println("ESCREVE CIDADES A/Z");
                    System.out.println("************************************");
                    arv.
                break;
                case 5:
                    System.out.println("************************************");
                    System.out.println("ESCREVE CIDADES Z/A");
                    System.out.println("************************************");
                    arv.posFixado();

                break;
                case 6:
                    System.out.println("************************************");
                    System.out.println("ESCREVE PAISES A/Z");
                    System.out.println("************************************");
                break;
                case 7:
                    System.out.println("************************************");
                    System.out.println("ESCREVE PAISES Z/A");
                    System.out.println("************************************");
                break;
                case 8:
                    System.out.println("************************************");
                    System.out.println("ESCREVE JOGADORES ORDEM CRESCENTE");
                    System.out.println("************************************");
                break;
                case 9:
                    System.out.println("************************************");
                    System.out.println("ESCREVE JOGADORES ORDEM DECRESCENTE");
                    System.out.println("************************************");
                break;
                case 10:
                    System.out.println("************************************");
                    System.out.println("CONSULTA CIDADES POR PAIS");
                    System.out.println("************************************");
                break;
                case 11:
                    System.out.println("************************************");
                    System.out.println("CONSULTA JOGADORES POR PAIS");
                    System.out.println("************************************");
                break;
                case 12:
                    System.out.println("************************************");
                    System.out.println("SAIR");
                    System.out.println("************************************");
                break;
                    
                default:
                }
                    menuLista();
                    menuOption = ler.nextInt();
                }while (menuOption != 12 );

		/*
		System.out.println("\n Pos-Fixado:\n");
		arv.posFixado( );			
		System.out.println("\n");	
		System.out.println(arv.pesquisa(c1));
		System.out.println("\n Remoção:\n");
		arv.remove( 100 );		
		arv.central();	
*/
	
}}